class CSV(object):
    def __init__(self, sep=','):
        self._sep = sep

    def read_csv(self, line):
        dummy = None
        if '"' in line:
            item_list = line.split('"')
            line = item_list[0]
            dummy= {}
            for i in range(1,len(item_list)-1):
                key = 'dummy_{0}'.format(i)
                line +='dummy_{0}'.format(i)
                dummy[key] = item_list[i]
            line += item_list[-1]
        line_list = line.strip().split(self._sep)
        if dummy:
            for i in range(len(line_list)):
                if line_list[i] in dummy:
                    line_list[i] = dummy[line_list[i]]
        return line_list