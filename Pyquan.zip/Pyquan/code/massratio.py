import re
import importdata as imp
reload(imp)


class AmdisCode(object):
    def __init__(self, code):
        self._code = code
        self._intensity = {}
        self._redata = re.compile(r'\([\d\s]*\)')
        #self._redata = re.compile(r'\(([\d+\s]*)\)')
        self._reintensity = re.compile(r'([\d]+)')
        #self._reintensity=re.compile(r'([\d]+)(?:[\s]+)([\d]+)')
        
    @property
    def intensity(self):
        return self._intensity
    
    def read_line(self, line):
        spectrum = re.findall(self._redata, line)
        for i in spectrum:
            mass, intensity = re.findall(self._reintensity,i)
            self._intensity[mass] = int(intensity)
        return
    

class Library(object):
    def __init__(self, library_amdis, min_mass, max_mass, library_project, csv):
        self._lib_amdis = library_amdis
        self._lib_proj = library_project
        self._min_mass = min_mass
        self._max_mass = max_mass
        self._csv = csv
        self.import_lib_amdis()
        self.read_library_project()
        
    def import_lib_amdis(self):
        self._amdis_dict = {}
        code = None
        amdis_code = None
        with open(self._lib_amdis, 'r') as amdis:
            for line in amdis:
                if line[:4] == 'NAME':
                    if code:
                        self._amdis_dict[code] = amdis_code.intensity
                    code = imp.correct_code(line.split(':')[1])
                    amdis_code = AmdisCode(code)
                elif line[0] == '(':
                    amdis_code.read_line(line)
            self._amdis_dict[code] = amdis_code.intensity
        return

    def CF(self, code):
        return self._CF[code]
    
    def get_CF(self, code, mass):
        TIC = float(sum(self._amdis_dict[code].itervalues()))
        return TIC / self._amdis_dict[code][mass]
        
    def read_library_project(self):
        self._CF = {}
        with open(self._lib_proj, 'r') as lib:
            lib.readline()            
            for line in lib:
                code, RT, lim, mass, name, source = self._csv.read_csv(line)
                self._CF[code] = self.get_CF(code, mass)
        return