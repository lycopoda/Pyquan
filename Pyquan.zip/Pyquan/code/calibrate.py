import matplotlib.pyplot as plt
import importdata as imp
import numpy as np
import sys, os.path, align, init
reload(imp)
reload(align)
reload(init)

class Datarun():
    def __init__(self, project_name):
        self._info = init.Info('pyquan.ini')
        self._path = init.Path(project_name, self._info)
        self._project_name = project_name
        self.create_dir()
        self._RT_project = {}
        self._fit_project = {}
        self._runlist = []
        with open(self._path.runlist_file_cal, 'r') as runlist:
            for line in runlist:
                self._runlist.append(line.strip().split(',')[0])
        lib_file = self._path.library_file
        with open(self._path.library_file_ref, 'r') as lib_ref, open(lib_file, 'w') as lib_new:
            for line in lib_ref:
                lib_new.write(line)

        
    @property
    def path(self):
        return self._path        
#-------------------------------------------------------------------------------        
    def get_data(self):
        '''collects information, unpack AMDIS file, and import RT and fit data'''
        self.move_amdis()
        self.get_all_RT()
        self.remove_ignore()
        self._RT = {}
        return

    def create_dir(self):
        if not os.path.exists(self._path._project_dir):
            os.mkdir(self._path._project_dir)
        if not os.path.exists(self._path.amdis_dir):
            os.mkdir(self._path.amdis_dir)
        if not os.path.exists(self._path.align_dir):
            os.mkdir(self._path.align_dir)
        return
        
    
    def move_amdis(self):
        if os.path.isfile(self._path.amdis_file):
            imp.amdis_batch(self._path)
            #os.unlink(self._path.amdis_file)
        return
        
    def get_all_RT(self):
        ID = {}
        ID['project'] = self._project_name
        for sample in self._runlist:
            ID['sample'] = sample
            sample_run = imp.Sample(ID,self._path, self._info.csv, cal=1)
            self._RT_project[sample], self._fit_project[sample] = sample_run.read_amdis(cal=1)
        return
            
    
    def remove_ignore(self):
        for sample in self._RT_project:
            try:
                for code in self._info.codes_ignore:
                    del self._RT_project[sample][code]
            except:
                pass
        return

#-------------------------------------------------------------------------------
    def align_samples(self):
        y_idx = self._info.sample_ref-1 #defines which sample refers as reference to align others too
        sample_y = self._runlist[y_idx]
        align_sample = align.AlignSample(self._path, sample_y,
                                                     self._RT_project[sample_y])
        CF_RT = {}
        CF_RT[sample_y] = (1.,0.)
        for sample in self._runlist:
            if not sample == sample_y:
                print '{0}\tcalibration'.format(sample),
                CF_RT[sample] = align_sample.align_sample(sample,
                                                       self._RT_project[sample])
                print 'finished'
        self._CF = self.align_ref(CF_RT)
        self.create_project_file()
        return
        
    def align_ref(self, CF_RT):
        library = imp.library_import(self._path.library_file_ref, self._info.csv)
        code_set = self.get_code_set()
        x = []
        y = []
        for code in (code_set):
            if code in library:
                y.append(library[code]['RT'])
                RT_list = []
                for sample in self._RT_project:
                    try:
                        RT_list.append(self._RT_project[sample][code])
                    except:
                        pass
                x.append(align.calc_median(RT_list))
        reg = align.Regression(x,y)
        CF_ref = reg.lin_robust()
        self.save_image_ref(x,y, CF_ref)
        CF = {}
        rc = CF_ref[0]
        ic = CF_ref[1]
        for sample in CF_RT:
            CF[sample] = (CF_RT[sample][0]*rc, CF_RT[sample][1]*rc+ic) 
        return CF
        
    def save_image_ref(self, x, y, CF):
        import os.path
        x_line = np.arange(0.,max(x))
        y_line = x_line*CF[0]+CF[1]
        x = np.array(x)
        y = np.array(y)
        plt.figure()
        plt.scatter(x,y)
        plt.plot(x_line, y_line, 'r-')
        plt.xlabel('RTs')
        plt.ylabel('ref')
        plot_name = os.path.join(self._path.align_dir,'reference.png')
        plt.savefig(plot_name)
        plt.close()
        return
        
    
    def create_project_file(self):
        quan_file = self._path.runlist_file
        with open(quan_file, 'w') as new:
            for sample in self._runlist:
                new.write('{0},{1},{2}\n'.format(sample, self._CF[sample][0],
                                                           self._CF[sample][1]))
        return
  
#-------------------------------------------------------------------------------
    def write_library(self):
        library = align.Library(self._path, self._info, self._RT_project, self._CF)
        library.write_lib()
        return
        
        
#-------------------------------------------------------------------------------    
    def write_files(self):
        '''writes files for RT, RT_ref and fit data'''
        self._code_set = self.get_code_set()
        file_dict={}
        file_dict['RT']={}
        file_dict['RT']['func'] = self.write_RT
        file_dict['fit']={}
        file_dict['fit']['func'] = self.write_fit
        file_dict['RT_ref'] = {}
        file_dict['RT_ref']['func'] = self.write_RT_ref
        for i in file_dict:
            file_dict[i]['file'] = self._path.align_data_file(i)
        for i in file_dict:
            self.write_header(file_dict[i]['file'])
            self.write_file(file_dict[i])
            #file_dict[i]['func'](file_dict[i]['file'], code_set)

    def write_header(self, file_name):
        with open(file_name, 'w') as f:
            f.write('code,')
            for sample in self._runlist:
                f.write('{0},'.format(sample))
            f.write('\n')
        return
    
    def write_RT(self, sample, code):
        if code in self._RT_project[sample]:
            RT = self._RT_project[sample][code]/60.
        else:
            RT = 'ND'
        return RT
        
    def write_RT_ref(self, sample, code):
        if code in self._RT_project[sample]:
            RT_ref = self._RT_project[sample][code]*self._CF[sample][0]+self._CF[sample][1]
        else:
            RT_ref = 'ND'
        return RT_ref  
        
    def write_fit(self, sample, code):
        if code in self._RT_project[sample]:
            fit = self._fit_project[sample][code]
        else:
            fit = 0
        return fit
    
    def write_file(self, file_dict):
        file_name = file_dict['file']
        function = file_dict['func']
        with open(file_name, 'a') as f:
            for code in sorted(self._code_set):
                f.write('{0},'.format(code))
                for sample in self._runlist:
                    item = function(sample, code)
                    f.write('{0},'.format(item))
                f.write('\n')
        return 

    def get_code_set(self):
        code_set = set()
        for sample in self._RT_project:
            for code in self._RT_project[sample]:
                code_set.add(code)
        return code_set

    def calc_median(x):
        sorts = sorted(x)
        length =len(sorts)
        if not length % 2:
            return (sorts[length / 2] + sorts[length /2 -1]) /2.0
        return sorts[length /2]            
#-------------------------------------------------------------------------------
    
class SaveImage():
    def __init__(self, project_dir, sample_x):
        self._dir = project_dir
        self._sample_x = sample_x
        
    def save_image(self, x, y, sample_y, CF):
        x_line = np.arange(0.,max(x))
        y_line = x_line*CF[0]+CF[1]
        x = np.array(x)
        y = np.array(y)
        plt.figure()
        plt.scatter(x,y)
        plt.plot(x_line, y_line, 'r-')
        plt.xlabel(self._sample_x)
        plt.ylabel(sample_y)
        plot_name = os.path.join(self._dir, 'alignment','{0}.png'.format(sample_y))
        plt.savefig(plot_name)
        plt.close()
        return

#-------------------------------------------------------------------------------

def main(project_name = None):
    if not project_name:
        import analyse
        project_name = analyse.get_project_name()
    print '{0}: start calibration'.format(project_name)
    project = Datarun(project_name)
    project.get_data()
    project.get_all_RT()
    project.align_samples()
    project.write_library()
    project.write_files()
    print('\a')
    return

if __name__=='__main__':
    status = main()
    sys.exit(status)