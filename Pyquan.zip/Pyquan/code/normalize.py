import baseline, sys, init, sec_min, os, peak_fit
import importdata as imp
import numpy as np
import matplotlib.pyplot as plt
reload(init)


class TICSample(object):

    def __init__(self, sample, datarun):
        self._sample = sample
        self._datarun = datarun
        self._cdf = imp.CDF(self._sample)
        self._code_list = []
        self._area_list = []
        self._peak_TIC=self._cdf.empty_TIC()
        
    def code_TIC(self, code, pars):
        self._time = self._cdf.get_time_list()
        return peak_fit.Fit.asym_peak(self._time, pars) * self._datarun.code_cf(code)
        
    def calc_peak_TIC(self):
        with open(self._datarun.datafile(self._sample), 'r') as data_file:
            for line in data_file:
                code, area, p1, p2, p3, p4 = line.strip().split(',')
                if p1 != 'None':
                    self._peak_TIC += self.code_TIC(code, [p1,p2,p3,p4])
                #else:
                    #
                self._code_list.append(code)
                self._area_list.append(float(area))
        return
    
    def calc(self):
        new_data = {}
        self.calc_peak_TIC()
        self._total_TIC = self._cdf.total_TIC()
        self._baseline = baseline.baseline_poly(self._cdf.get_time_list(),
                                                self._total_TIC, window=50, deg=10)
        norm = sum(self._total_TIC) - sum(self._baseline)
        self.save_images()
        area_new = np.array(self._area_list) / norm
        for i in range(len(self._code_list)):
            new_data[self._code_list[i]] = area_new[i]
        return new_data
        
    
    def save_images(self):
        step = 10.
        lim = {}
        lim['complete']=[0,1]
        for i in range(1,int(step)+1):
            lim[i] = []
            lim[i].append(i/step-1/step)
            lim[i].append(i/step)
        self.save_image(lim)
        return
    
    def save_image(self, lim):
        plt.figure()
        time = self._time/60.
        plt.plot(time,self._total_TIC, 'k-')
        plt.plot(time, self._peak_TIC+self._baseline, 'r-')
        plt.plot(time, self._baseline, 'b-')
        #plt.plot(time, self._peak_TIC, 'r-')
        #plt.plot(time, self._total_TIC-self._peak_TIC, 'b-')
        plt.xlabel('time (min)')
        plt.ylabel('TIC')
        x_max = max(time)
        for i in lim:
            plt.xlim(lim[i][0]*x_max,lim[i][1]*x_max)
            plot_name = self._datarun.plotname(self._sample,str(i))
            plt.savefig(plot_name)
        plt.close()
        return


class Datarun(object):

    def __init__(self, project_name):
        self._project_name = project_name
        self._info = init.Info('pyquan.ini')
        self._path = init.Path(project_name, self._info)
        self._library = imp.library_import(self._path.library_file, self._info.csv)
        self._runlist = []
        self.import_cf()
        with open(self._path.runlist_file, 'r') as runlist:
            for line in runlist:
                self._runlist.append(line.split(',')[0])
    
    def import_cf(self):
        import massratio
        reload(massratio)
        self._code_missing = set()
        lib_amdis = self._path.library_amdis
        min_mass, max_mass = self._info.mass_limits
        lib_project = self._path.library_file
        self._CF = massratio.Library(lib_amdis, min_mass,max_mass, lib_project, self._info.csv)
        return
    
    def code_cf(self,code):
        try:
            CF = self._CF.CF(code)
        except:
            print '{0} missing from AMDIS library'.format(code)
        return CF
        
    @property
    def runlist(self):
        return self._runlist
        
    @property
    def method(self):
        return self._info.norm_meth
        
    def datafile(self, sample):
        return self._path.data_file(sample)
        
    def norm_dir(self):
        path = self._path.norm_dir
        if not os.path.exists(path):
            os.mkdir(path)
        return
        
    def plotname(self, sample, part):
        return self._path.norm_fig_file(sample, part)

#---Output file-----------------------------------------------------------------
        
    def header(self):
        line = 'code,name,source,'
        for sample in self.runlist:
            line+='{0},'.format(sample)
        line += '\n'
        return line
    
    def line(self, new_data, code):
        name = self._library[code]['name']
        source = self._library[code]['source']
        line = '{0},{1},{2},'.format(code, name, source)
        for sample in self.runlist:
            if code in new_data[sample]:
                line += '{0},'.format(str(new_data[sample][code]))
            else:
                line += 'ND,'
        line +=  '\n'
        return line 
    
    def save_output(self, new_data, codeset):
        with open(self._path.output_file, 'w') as output:
            output.write(self.header())
            for code in sorted(codeset):
                output.write(self.line(new_data,code))
        return
        
    def get_fit_dict(self, sample):
        fit_dict = {}
        with open(self._path.fit_file(sample), 'r') as fit_file:
            for line in fit_file:
                code, fit = line.strip().split(',')
                fit_dict[code] = fit
        return fit_dict
        
    def get_RT_dict(self, sample):
        RT_dict = {}
        with open(self._path.RT_file(sample), 'r') as RT_file:
            for line in RT_file:
                code, RT = line.strip().split(',')
                RT_dict[code] = RT
        return RT_dict
    
    
    def write_data(self, sample, CF, fit_dict, RT_dict, codeset):
        with open(self._path.norm_fit_file, 'a') as fit_file:
            fit_file.write('{0},'.format(sample))
            for code in sorted(codeset):
                if code in fit_dict:
                    fit_file.write('{0},'.format(fit_dict[code]))
                else:
                    fit_file.write('ND,')
            fit_file.write('\n')
        with open(self._path.norm_RT_file, 'a') as RT_file:
            RT_file.write('{0},'.format(sample))
            for code in sorted(codeset):
                if code in RT_dict:
                    RT_file.write('{0},'.format(float(RT_dict[code])/60.))
                else:
                    RT_file.write('ND,')
            RT_file.write('\n')
        with open(self._path.norm_RT_ref_file, 'a') as RT_ref_file:
            RT_ref_file.write('{0},'.format(sample))
            for code in sorted(codeset):
                if code in RT_dict:
                    RT_ref = float(RT_dict[code]) * CF[0] + CF[1]
                    RT_ref_file.write('{0},'.format(RT_ref))
                else:
                    RT_ref_file.write('ND,')
            RT_ref_file.write('\n')

    def header_data(self, codeset):
        header = 'sample,'
        for code in sorted(codeset):
            header+='{0},'.format(code)
        header+='\n'
        return header
    
    def save_data(self, codeset):
        CF = {}
        runlist=[]
        with open(self._path.norm_fit_file, 'w') as fit_file:
            fit_file.write(self.header_data(codeset))
        with open(self._path.norm_RT_file, 'w') as RT_file:
            RT_file.write(self.header_data(codeset))
        with open(self._path.norm_RT_ref_file, 'w') as RT_ref_file:
            RT_ref_file.write(self.header_data(codeset))
        with open(self._path.runlist_file, 'r') as runlist_file:
            for line in runlist_file:
                sample, rc, ic = line.strip().split(',')
                runlist.append(sample)
                CF = (float(rc), float(ic))
                fit_dict = self.get_fit_dict(sample)
                RT_dict = self.get_RT_dict(sample)
                self.write_data(sample, CF, fit_dict, RT_dict, codeset)
        return

#-------------------------------------------------------------------------------        

def norm_TIC(datarun):
    new_data = {}
    codeset = set()
    for sample in datarun.runlist:
        print '{0}\tnormalization'.format(sample),
        samplerun = TICSample(sample, datarun)
        new_data[sample] = samplerun.calc()
        for code in new_data[sample]:
            codeset.add(code)
        print 'finished'
    return new_data, codeset

def main(project_name = None):
    start_time = timeit.default_timer()
    if not project_name:
        import analyse
        project_name = analyse.get_project_name()
    print '{0}: start normalization'.format(project_name)
    datarun = Datarun(project_name)
    if datarun.method == 'total_TIC':
        datarun.norm_dir()
        new_data, codeset = norm_TIC(datarun)
    datarun.save_output(new_data, codeset)
    datarun.save_data(codeset)
    print sec_min.sec_min(timeit.default_timer() - start_time)
    print('\a')
    return


if __name__=='__main__':
    status = main()
    sys.exit(status)
        
