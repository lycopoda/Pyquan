import re, shutil
import sys, os
from argparse import ArgumentParser


class AmdisCode(object):
    def __init__(self, code):
        self._code = code
        self._intensity = {}
        self._redata = re.compile(r'\([\d\s]*\)')
        #self._redata = re.compile(r'\(([\d+\s]*)\)')
        self._reintensity = re.compile(r'([\d]+)')
        #self._reintensity=re.compile(r'([\d]+)(?:[\s]+)([\d]+)')
        
    @property
    def intensity(self):
        return self._intensity
    
    def read_line(self, line):
        spectrum = re.findall(self._redata, line)
        for i in spectrum:
            mass, intensity = re.findall(self._reintensity,i)
            self._intensity[mass] = int(intensity)
        return
    

class Library(object):
    def __init__(self, amdis_file, min_mass, max_mass):
        lib_dic = os.path.join('..','library')
        self._amdis_file = os.path.join(lib_dic,amdis_file)
        self._min_mass = min_mass
        self._max_mass = max_mass
        self._lib_file = os.path.join(lib_dic, 'library_ref.txt')
        self._backup = os.path.join(lib_dic, 'library_ref.tmp')
    
    def get_CF(self, code, mass):
        TIC = float(sum(self._amdis_dict[code].itervalues()))
        return str(TIC / self._amdis_dict[code][mass])
                                                
    def write_lib(self):
        shutil.copyfile(self._lib_file, self._backup)
        self._mis_amdis = set()
        with open(self._lib_file, 'w') as ref, open(self._backup, 'r') as backup:
            for line in backup:
                info = line.split('\t')
                try:
                    info[4] = self.get_CF(info[0],info[3])
                    ref.write('\t'.join(info))
                except:
                    self._mis_amdis.add(info[0])
        return
                
    def import_lib_amdis(self):
        self._amdis_dict = {}
        code = None
        amdis_code = None
        with open(self._amdis_file, 'r') as amdis:
            for line in amdis:
                if line[:4] == 'NAME':
                    if code:
                        self._amdis_dict[code] = amdis_code.intensity
                    code = line.split(':')[1]
                    amdis_code = AmdisCode(code)
                elif line[0] == '(':
                    amdis_code.read_line(line)
        return
    
    def save_missing_amdis(self):
        mis_file = os.path.join('..','library','missing_amdis.txt')
        with open(mis_file, 'w') as mis:
            for code in self._mis_amdis:
                mis.write('{0}\n'.format(code))
        return
    
    def check_library(self):
        self.import_lib_amdis()
        self.write_lib()
        if self._mis_amdis:
            return 1
        return 0
        

def main():
    arg_parser = ArgumentParser(description = 'Calculate mass to TIC factors')
    arg_parser.add_argument('amdis_file', metavar='Amdis library file name', help='Amdis library file name, stored in folder library')
    arg_parser.add_argument('min_mass', metavar='Minimum of mass range, measured in MS', type=int)
    arg_parser.add_argument('max_mass', metavar='Maximum of mass range, measured in MS', type=int)
    options = arg_parser.parse_args()
    library = Library(options.amdis_file,options.min_mass,options.max_mass)
    status = library.check_library()
    if status == 1:
        library.save_missing()
    print('\a')
    return status

if __name__=='__main__':
    status = main()
    sys.exit(status)          
            
            