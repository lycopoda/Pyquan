import numpy as np
import peak_fit

class Code():
    def __init__(self, ID, path, cdf, window = 120):
        self._path = path
        self._cdf = cdf
        self._n_scan = len(cdf._scan_time)
        self._time_max = max(cdf._scan_time)
        self._ID = ID
        self._window = window
        
    def area(self, pars, noise, fit_peak='yes'):
        '''fit peak, and return parameter and area data'''
        area = None
        param_fit = {}
        if self._ID['RT']<self._time_max:
            self.get_data()
            self._y = noise.correct(self._x,self._y)
            params, x_fit, y_fit = pars.get_param(self._x,self._y, self._ID['RT'])
            if params:
                fit = peak_fit.Fit(params, x_fit, y_fit)
                if fit_peak == 'yes':
                    area, param_fit, fit_peak = fit.peak_fit()
                else:
                    area = fit.real_area()
                    if param_fit:
                        param_fit['int'] = (None, None, None, None)
                self.save_image(param_fit, fit._x_fit/60., fit._y_fit, fit_peak=fit_peak)
            else:
                area = None
                param_fit['int'] = [(),(),(),()]
        return area, param_fit
    
    def get_data(self):
        import baseline
        t_idx = self._cdf.get_time_index(self._ID['RT'])
        x = []
        y = []
        for t in range(t_idx-self._window, t_idx+self._window):
            if t< self._n_scan-2:
                x.append(self._cdf.get_time(t))
                y.append(self._cdf.intensity(t, self._ID['mass']))
        y -= baseline.baseline_poly(np.array(x),np.array(y), window=self._window/2, deg=2)
        lim = self._window/2
        self._x = x[lim:-lim]
        self._y = y[lim:-lim]
        return
        
    def save_image(self, pars, x_fit, y_fit, fit_peak = 'yes'):
        import matplotlib.pyplot as plt
        x = np.array(self._x)
        x_plot = x/60. #back to minutes
        y = np.array(self._y)
        plt.figure()
        plt.plot(x_plot,y)
        plt.xlabel('Time (min)')
        plt.ylabel('intensity')
        plot_name = self._path.pyquan_fig_file(self._ID['code'], self._ID['sample'])
        if fit_peak is 'yes':
            for i in pars:
                if pars[i][0]:
                    peak = peak_fit.Fit.asym_peak(x, pars[i])
                    if i == 'int':
                        plt.plot(x_plot, peak, 'r-')
                    else:
                        plt.plot(x_plot, peak, 'y-')
        else:
            plt.plot(x_fit, y_fit, 'r-')
        plt.savefig(plot_name)
        plt.close()
        return
