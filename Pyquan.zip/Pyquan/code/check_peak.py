import sys, init, peak
import importdata as imp
import peak_pars as pars
import noise_reduction as noise
reload(init)
reload(peak)
reload(imp)
reload(pars)

class Project(object):
    def __init__(self, project_name, info, csv):
        self._path = init.Path(project_name, info)
        self._csv = csv
        self._info = info
        self._library = imp.library_import(self._path.library_file, csv)
        self._param = pars.Pars(self._info)
        self._noise = noise.NoiseReduction(self._info)
        self._window = info.peak_window
        
    @property
    def window(self):
        return self._window
    
    def get_runlist(self):
        runlist = []
        CFdict = {}
        with open(self._path.runlist_file, 'r') as runlistfile:
            for line in runlistfile:
                sample, rc, ic = line.strip().split(',')
                runlist.append(sample)
                CFdict[sample] = (float(rc), float(ic))
        return runlist, CFdict
        

class Sample(object):
    def __init__(self, ID, project, csv):
        self._project = project
        self._ID = ID
        self._cdf = imp.CDF(ID['sample'])
        self._imp = imp.Sample(ID, project._path, csv)
        
    def read_data(self):
        self._imp.read_amdis()
        self._imp.backfill()
        self._cdf.import_data()
        return
        
    def update_ID(self, code):
        self._ID['code'] = code
        RT = self._imp._RT_dict[code]
        if not self._ID['RT']:
            self._ID['RT'] = RT
        self._ID['mass'] = self._project._library[code]['mass']
        print '{0}\t{1}\tRT: {2}'.format(self._ID['sample'],self._ID['code'],
                                                             self._ID['RT']/60.)
        return
    
    def dataline(self, code, area, param_fit):
        if not param_fit:
            fit=[None, None, None, None]
        else:
            fit = param_fit['int']
        return ('{0},{1},{2},{3},{4},{5}\n'.format(code,area,fit[0],fit[1],fit[2],fit[3]))
    
    def quantify_peaks(self):
        self.read_data()
        code_check = self._project._info.code_check
        with open(self._project._path.data_file(self._ID['sample']), 'r') as old:
            data_old = old.readlines()
        with open(self._project._path.data_file(self._ID['sample']), 'w') as datafile:
            for line in data_old:
                code = line.split(',')[0]
                if code != code_check:
                    datafile.write(line)
            self.update_ID(code_check)
            peak_fit = peak.Code(self._ID, self._project._path, self._cdf, window=self._project.window)
            area, param_fit = peak_fit.area(self._project._param,
                         self._project._noise, fit_peak=self._project._info.fit_peak)
            line = self.dataline(code_check, area, param_fit)
            datafile.write(line)
        return


def main():
    info = init.Info('check_peak.ini')
    csv = init.Info('pyquan.ini').csv
    RT = info.RT_check
    project_name = info.project_name_check
    datarun = Project(project_name, info, csv)
    samplelist, CFdict = datarun.get_runlist()
    sample_check = info.sample_check
    if sample_check != 'all':
        samplelist = [sample_check]
    for sample in samplelist:
        ID = {}
        ID['sample'] = sample
        ID['CF'] = CFdict[sample]
        ID['RT'] = RT
        samplerun = Sample(ID, datarun, csv)
        samplerun.quantify_peaks()
    print('\a')


if __name__=='__main__':
    status = main()
    sys.exit(status)
