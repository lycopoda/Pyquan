import sys, init, peak, os
import importdata as imp
import peak_pars as pars
import noise_reduction as noise
reload(imp)
reload(peak)
reload(init)


class Project(object):
    def __init__(self, project_name):
        self._info = init.Info('pyquan.ini')
        self._path = init.Path(project_name, self._info)
        self.create_dir()
        self._library = imp.library_import(self._path.library_file,
			self._info.csv)
        self._param = pars.Pars(self._info)
        self._noise = noise.NoiseReduction(self._info)
        
    @property
    def info(self):
        return self._info
    
    def create_dir(self):
        if not os.path.exists(self._path.data_dir):
            os.mkdir(self._path.data_dir)
        if not os.path.exists(self._path.images_dir):
            os.mkdir(self._path.images_dir)
        return
    
    def get_runlist(self):
        runlist = []
        CFdict = {}
        with open(self._path.runlist_file, 'r') as runlistfile:
            for line in runlistfile:
                sample, rc, ic = line.strip().split(',')
                runlist.append(sample)
                CFdict[sample] = (float(rc), float(ic))
        return runlist, CFdict
        

class Sample(object):
    def __init__(self, ID, project):
        self._project = project
        self._sample = ID['sample']
        self._cdf = imp.CDF(ID['sample'])
        self._imp = imp.Sample(ID, project._path, project.info.csv, cal=0)
        
    def read_data(self):
        self._imp.read_amdis()
        self._imp.backfill()
        self._imp.write_data()
        self._cdf.import_data()
        return
        
    def get_ID(self, code):
        ID={}
        ID['sample'] = self._sample
        ID['code'] = code
        ID['RT'] = self._imp._RT_dict[code]
        ID['mass'] = self._project._library[code]['mass']
        return ID
    
    def dataline(self, code, area, fit):
        return ('{0},{1},{2},{3},{4},{5}\n'.format(code,area,fit[0],fit[1],fit[2],fit[3]))
    
    def quantify_peaks(self):
        self.read_data()
        with open(self._project._path.data_file(self._sample), 'w') as datafile:
            for code in self._imp.RT_dict:
                ID = self.get_ID(code)
                peak_fit = peak.Code(ID, self._project._path, self._cdf)
                area, param_fit = peak_fit.area(self._project._param,
				  self._project._noise)
                if area != None:
                    line = self.dataline(code, area, param_fit['int'])
                    datafile.write(line)
        self._cdf.close_cdf()
        return


def main(project_name = None):
    if not project_name:
        import analyse
        project_name = analyse.get_project_name()
    datarun = Project(project_name)
    if not project_name:
        project_name = sys.argv[1]
    datarun = Project(project_name)
    samplelist, CFdict = datarun.get_runlist()
    for sample in samplelist:
        print '{0}: quantification '.format(sample),
        ID = {}
        ID['sample'] = sample
        ID['CF'] = CFdict[sample]
        samplerun = Sample(ID, datarun)
        samplerun.quantify_peaks()
	print 'finished'
    print('\a')


if __name__=='__main__':
    status = main()
    sys.exit(status)
